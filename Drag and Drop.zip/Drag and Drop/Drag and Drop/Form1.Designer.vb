﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDragDrop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstItems = New System.Windows.Forms.ListBox()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.lblInput = New System.Windows.Forms.Label()
        Me.lblSource = New System.Windows.Forms.Label()
        Me.lblDestination = New System.Windows.Forms.Label()
        Me.imgQuit = New System.Windows.Forms.PictureBox()
        Me.imgFederation = New System.Windows.Forms.PictureBox()
        Me.imgKlingon = New System.Windows.Forms.PictureBox()
        Me.imgTarget = New System.Windows.Forms.PictureBox()
        CType(Me.imgQuit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgFederation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgKlingon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgTarget, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lstItems
        '
        Me.lstItems.AllowDrop = True
        Me.lstItems.FormattingEnabled = True
        Me.lstItems.Location = New System.Drawing.Point(188, 70)
        Me.lstItems.Name = "lstItems"
        Me.lstItems.Size = New System.Drawing.Size(120, 173)
        Me.lstItems.TabIndex = 0
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(41, 70)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(101, 20)
        Me.txtInput.TabIndex = 2
        '
        'lblInput
        '
        Me.lblInput.AutoSize = True
        Me.lblInput.Location = New System.Drawing.Point(38, 54)
        Me.lblInput.Name = "lblInput"
        Me.lblInput.Size = New System.Drawing.Size(104, 13)
        Me.lblInput.TabIndex = 3
        Me.lblInput.Text = "Type in a word here:"
        '
        'lblSource
        '
        Me.lblSource.AutoSize = True
        Me.lblSource.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSource.Location = New System.Drawing.Point(42, 17)
        Me.lblSource.Name = "lblSource"
        Me.lblSource.Size = New System.Drawing.Size(83, 26)
        Me.lblSource.TabIndex = 4
        Me.lblSource.Text = "Sources"
        '
        'lblDestination
        '
        Me.lblDestination.AutoSize = True
        Me.lblDestination.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDestination.Location = New System.Drawing.Point(190, 17)
        Me.lblDestination.Name = "lblDestination"
        Me.lblDestination.Size = New System.Drawing.Size(118, 26)
        Me.lblDestination.TabIndex = 5
        Me.lblDestination.Text = "Destinations"
        '
        'imgQuit
        '
        Me.imgQuit.Image = Global.Drag_and_Drop.My.Resources.Resources._exit
        Me.imgQuit.Location = New System.Drawing.Point(42, 350)
        Me.imgQuit.Name = "imgQuit"
        Me.imgQuit.Size = New System.Drawing.Size(100, 39)
        Me.imgQuit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgQuit.TabIndex = 8
        Me.imgQuit.TabStop = False
        '
        'imgFederation
        '
        Me.imgFederation.Image = Global.Drag_and_Drop.My.Resources.Resources.Federation
        Me.imgFederation.Location = New System.Drawing.Point(42, 232)
        Me.imgFederation.Name = "imgFederation"
        Me.imgFederation.Size = New System.Drawing.Size(100, 112)
        Me.imgFederation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgFederation.TabIndex = 7
        Me.imgFederation.TabStop = False
        '
        'imgKlingon
        '
        Me.imgKlingon.Image = Global.Drag_and_Drop.My.Resources.Resources.Klingon
        Me.imgKlingon.Location = New System.Drawing.Point(41, 96)
        Me.imgKlingon.Name = "imgKlingon"
        Me.imgKlingon.Size = New System.Drawing.Size(101, 130)
        Me.imgKlingon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgKlingon.TabIndex = 6
        Me.imgKlingon.TabStop = False
        '
        'imgTarget
        '
        Me.imgTarget.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.imgTarget.Location = New System.Drawing.Point(188, 258)
        Me.imgTarget.Name = "imgTarget"
        Me.imgTarget.Size = New System.Drawing.Size(120, 131)
        Me.imgTarget.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgTarget.TabIndex = 1
        Me.imgTarget.TabStop = False
        '
        'frmDragDrop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 403)
        Me.Controls.Add(Me.imgQuit)
        Me.Controls.Add(Me.imgFederation)
        Me.Controls.Add(Me.imgKlingon)
        Me.Controls.Add(Me.lblDestination)
        Me.Controls.Add(Me.lblSource)
        Me.Controls.Add(Me.lblInput)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.imgTarget)
        Me.Controls.Add(Me.lstItems)
        Me.Name = "frmDragDrop"
        Me.Text = "Drag and Drop"
        CType(Me.imgQuit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgFederation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgKlingon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgTarget, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstItems As ListBox
    Friend WithEvents imgTarget As PictureBox
    Friend WithEvents txtInput As TextBox
    Friend WithEvents lblInput As Label
    Friend WithEvents lblSource As Label
    Friend WithEvents lblDestination As Label
    Friend WithEvents imgKlingon As PictureBox
    Friend WithEvents imgFederation As PictureBox
    Friend WithEvents imgQuit As PictureBox
End Class
