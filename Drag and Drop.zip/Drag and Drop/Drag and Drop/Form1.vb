﻿Public Class frmDragDrop
    Private Sub frmDragDrop_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'The AllowDrop property of a PictureBox does not appear in 
        'the Properties menu, so it must be set here.
        imgTarget.AllowDrop = True

    End Sub

    Private Sub txtInput_MouseDown(sender As Object, e As MouseEventArgs) Handles txtInput.MouseDown
        'Whatever text is in the Text property of the TextBox is the data that will accompany this drag.
        txtInput.DoDragDrop(txtInput.Text, DragDropEffects.Copy)
    End Sub

    Private Sub lstItems_DragEnter(sender As Object, e As DragEventArgs) Handles lstItems.DragEnter
        'Make a copy of the item that has been dragged over the ListBox
        e.Effect = DragDropEffects.Copy
    End Sub

    Private Sub lstItems_DragDrop(sender As Object, e As DragEventArgs) Handles lstItems.DragDrop
        'We will convert the text that has been dragged into the ListBox to uppercase, and then add the text to its items.
        lstItems.Items.Add(e.Data.GetData(DataFormats.Text).ToString().ToUpper())
    End Sub

    Private Sub imgFederation_MouseDown(sender As Object, e As MouseEventArgs) Handles imgFederation.MouseDown
        'The String 'federation' is the data that will accompany the drag.
        imgFederation.DoDragDrop("federation", DragDropEffects.Copy)
    End Sub

    Private Sub imgTarget_DragEnter(sender As Object, e As DragEventArgs) Handles imgTarget.DragEnter
        'Make a copy of the item that has been dragged over the PictureBox
        e.Effect = DragDropEffects.Copy

    End Sub

    Private Sub imgTarget_DragDrop(sender As Object, e As DragEventArgs) Handles imgTarget.DragDrop
        'If Text was dropped it will be stored here
        Dim strDragItem As String
        'Stores what was dropped in a String variable.  The text is also converted to uppercase.
        strDragItem = e.Data.GetData(DataFormats.Text).ToString().ToUpper()
        'We made our program only drag text.  We can inspect the text that has been dragged and act accordingly.
        If strDragItem = "FEDERATION" Then
            imgTarget.Image = My.Resources.enterprise
        ElseIf strDragItem = "KLINGON" Then
            imgTarget.Image = My.Resources.BirdofPrey
        ElseIf strDragItem = "EXIT" Then
            Me.Close()
        Else
            imgTarget.Image = My.Resources.confusion
        End If
    End Sub

    Private Sub imgKlingon_MouseDown(sender As Object, e As MouseEventArgs) Handles imgKlingon.MouseDown
        'The String 'klingon' is the data that will accompany the drag.
        imgKlingon.DoDragDrop("klingon", DragDropEffects.Copy)
    End Sub

    Private Sub imgQuit_MouseDown(sender As Object, e As MouseEventArgs) Handles imgQuit.MouseDown
        'The String 'exit' is the data that will accompany the drag.
        imgQuit.DoDragDrop("exit", DragDropEffects.Copy)
    End Sub



End Class
